﻿namespace SOFT152_Assignment
{
    partial class frmAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.combYear1 = new System.Windows.Forms.ComboBox();
            this.combLocation1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.combYear2 = new System.Windows.Forms.ComboBox();
            this.combLocation2 = new System.Windows.Forms.ComboBox();
            this.picChart = new System.Windows.Forms.PictureBox();
            this.btnPlotChart = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.combDataChoice = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.combLocation = new System.Windows.Forms.ComboBox();
            this.combYear = new System.Windows.Forms.ComboBox();
            this.btnback = new System.Windows.Forms.Button();
            this.lbl0of5 = new System.Windows.Forms.Label();
            this.lbl5of5 = new System.Windows.Forms.Label();
            this.lbl2of5 = new System.Windows.Forms.Label();
            this.lbl1of5 = new System.Windows.Forms.Label();
            this.lbl3of5 = new System.Windows.Forms.Label();
            this.lbl4of5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picChart)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(255, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Year #1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(236, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Location #1";
            // 
            // combYear1
            // 
            this.combYear1.FormattingEnabled = true;
            this.combYear1.Location = new System.Drawing.Point(306, 87);
            this.combYear1.Name = "combYear1";
            this.combYear1.Size = new System.Drawing.Size(96, 21);
            this.combYear1.TabIndex = 7;
            this.combYear1.SelectedIndexChanged += new System.EventHandler(this.combYear1_SelectedIndexChanged);
            // 
            // combLocation1
            // 
            this.combLocation1.FormattingEnabled = true;
            this.combLocation1.Location = new System.Drawing.Point(306, 32);
            this.combLocation1.Name = "combLocation1";
            this.combLocation1.Size = new System.Drawing.Size(96, 21);
            this.combLocation1.TabIndex = 6;
            this.combLocation1.SelectedIndexChanged += new System.EventHandler(this.combLocation1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(427, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Year #2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(408, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Location #2";
            // 
            // combYear2
            // 
            this.combYear2.FormattingEnabled = true;
            this.combYear2.Location = new System.Drawing.Point(478, 87);
            this.combYear2.Name = "combYear2";
            this.combYear2.Size = new System.Drawing.Size(96, 21);
            this.combYear2.TabIndex = 13;
            this.combYear2.SelectedIndexChanged += new System.EventHandler(this.combYear2_SelectedIndexChanged);
            // 
            // combLocation2
            // 
            this.combLocation2.FormattingEnabled = true;
            this.combLocation2.Location = new System.Drawing.Point(478, 32);
            this.combLocation2.Name = "combLocation2";
            this.combLocation2.Size = new System.Drawing.Size(96, 21);
            this.combLocation2.TabIndex = 12;
            this.combLocation2.SelectedIndexChanged += new System.EventHandler(this.combLocation2_SelectedIndexChanged);
            // 
            // picChart
            // 
            this.picChart.Location = new System.Drawing.Point(291, 188);
            this.picChart.Name = "picChart";
            this.picChart.Size = new System.Drawing.Size(500, 250);
            this.picChart.TabIndex = 19;
            this.picChart.TabStop = false;
            // 
            // btnPlotChart
            // 
            this.btnPlotChart.Location = new System.Drawing.Point(616, 30);
            this.btnPlotChart.Name = "btnPlotChart";
            this.btnPlotChart.Size = new System.Drawing.Size(175, 32);
            this.btnPlotChart.TabIndex = 20;
            this.btnPlotChart.Text = "Plot on chart";
            this.btnPlotChart.UseVisualStyleBackColor = true;
            this.btnPlotChart.Click += new System.EventHandler(this.btnPlotChart_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(65, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Location";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(84, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Year";
            // 
            // combDataChoice
            // 
            this.combDataChoice.FormattingEnabled = true;
            this.combDataChoice.Location = new System.Drawing.Point(420, 132);
            this.combDataChoice.Name = "combDataChoice";
            this.combDataChoice.Size = new System.Drawing.Size(154, 21);
            this.combDataChoice.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(301, 135);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Data you want to view";
            // 
            // combLocation
            // 
            this.combLocation.FormattingEnabled = true;
            this.combLocation.Location = new System.Drawing.Point(119, 32);
            this.combLocation.Name = "combLocation";
            this.combLocation.Size = new System.Drawing.Size(96, 21);
            this.combLocation.TabIndex = 23;
            this.combLocation.SelectedIndexChanged += new System.EventHandler(this.combLocation_SelectedIndexChanged);
            // 
            // combYear
            // 
            this.combYear.FormattingEnabled = true;
            this.combYear.Location = new System.Drawing.Point(119, 87);
            this.combYear.Name = "combYear";
            this.combYear.Size = new System.Drawing.Size(96, 21);
            this.combYear.TabIndex = 24;
            this.combYear.SelectedIndexChanged += new System.EventHandler(this.combYear_SelectedIndexChanged);
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(19, 383);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(144, 42);
            this.btnback.TabIndex = 25;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // lbl0of5
            // 
            this.lbl0of5.AutoSize = true;
            this.lbl0of5.Location = new System.Drawing.Point(272, 428);
            this.lbl0of5.Name = "lbl0of5";
            this.lbl0of5.Size = new System.Drawing.Size(13, 13);
            this.lbl0of5.TabIndex = 26;
            this.lbl0of5.Text = "0";
            // 
            // lbl5of5
            // 
            this.lbl5of5.AutoSize = true;
            this.lbl5of5.Location = new System.Drawing.Point(260, 188);
            this.lbl5of5.Name = "lbl5of5";
            this.lbl5of5.Size = new System.Drawing.Size(25, 13);
            this.lbl5of5.TabIndex = 26;
            this.lbl5of5.Text = "250";
            // 
            // lbl2of5
            // 
            this.lbl2of5.AutoSize = true;
            this.lbl2of5.Location = new System.Drawing.Point(260, 337);
            this.lbl2of5.Name = "lbl2of5";
            this.lbl2of5.Size = new System.Drawing.Size(25, 13);
            this.lbl2of5.TabIndex = 26;
            this.lbl2of5.Text = "100";
            // 
            // lbl1of5
            // 
            this.lbl1of5.AutoSize = true;
            this.lbl1of5.Location = new System.Drawing.Point(266, 383);
            this.lbl1of5.Name = "lbl1of5";
            this.lbl1of5.Size = new System.Drawing.Size(19, 13);
            this.lbl1of5.TabIndex = 26;
            this.lbl1of5.Text = "50";
            // 
            // lbl3of5
            // 
            this.lbl3of5.AutoSize = true;
            this.lbl3of5.Location = new System.Drawing.Point(260, 285);
            this.lbl3of5.Name = "lbl3of5";
            this.lbl3of5.Size = new System.Drawing.Size(25, 13);
            this.lbl3of5.TabIndex = 26;
            this.lbl3of5.Text = "150";
            // 
            // lbl4of5
            // 
            this.lbl4of5.AutoSize = true;
            this.lbl4of5.Location = new System.Drawing.Point(260, 236);
            this.lbl4of5.Name = "lbl4of5";
            this.lbl4of5.Size = new System.Drawing.Size(25, 13);
            this.lbl4of5.TabIndex = 26;
            this.lbl4of5.Text = "200";
            // 
            // frmAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl3of5);
            this.Controls.Add(this.lbl1of5);
            this.Controls.Add(this.lbl2of5);
            this.Controls.Add(this.lbl4of5);
            this.Controls.Add(this.lbl5of5);
            this.Controls.Add(this.lbl0of5);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.combYear);
            this.Controls.Add(this.combLocation);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.combDataChoice);
            this.Controls.Add(this.btnPlotChart);
            this.Controls.Add(this.picChart);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.combYear2);
            this.Controls.Add(this.combLocation2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combYear1);
            this.Controls.Add(this.combLocation1);
            this.Name = "frmAnalysis";
            this.Text = "frmAnalysis";
            this.Load += new System.EventHandler(this.frmAnalysis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox combYear1;
        private System.Windows.Forms.ComboBox combLocation1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combYear2;
        private System.Windows.Forms.ComboBox combLocation2;
        private System.Windows.Forms.PictureBox picChart;
        private System.Windows.Forms.Button btnPlotChart;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox combDataChoice;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox combLocation;
        private System.Windows.Forms.ComboBox combYear;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label lbl0of5;
        private System.Windows.Forms.Label lbl5of5;
        private System.Windows.Forms.Label lbl2of5;
        private System.Windows.Forms.Label lbl1of5;
        private System.Windows.Forms.Label lbl3of5;
        private System.Windows.Forms.Label lbl4of5;
    }
}